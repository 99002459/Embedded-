/*
 * STM32F407XX_GPIO_DRIVER.c
 *
 *  Created on: 30-Sep-2020
 *      Author: Training
 */
#include "stm32f407xx_gpio_driver.h"

void GPIO_init(GPIO_Handle_t *GPIO_Handle, uint8_t EnorDi)
{
	if(EnorDi==ENABLE){
	if(pGPIOx==GPIOA)
	{
		GPIOA_PCLCK_EN();
	}
	else if(pGPIOx==GPIOB)
	{
		GPIOB_PCLCK_EN();
	}
	else if(pGPIOx==GPIOC)
	{
		GPIOC_PCLCK_EN();
	}
	else if(pGPIOx==GPIOD)
		{
			GPIOD_PCLCK_EN();
		}
	else if(pGPIOx==GPIOE)
		{
			GPIOE_PCLCK_EN();
		}
	else if(pGPIOx==GPIOF)
		{
			GPIOF_PCLCK_EN();
		}
	else if(pGPIOx==GPIOG)
			{
				GPIOG_PCLCK_EN();
			}
	else if(pGPIOx==GPIOH)
			{
				GPIOH_PCLCK_EN();
			}
	else if(pGPIOx==GPIOI)
			{
				GPIOI_PCLCK_EN();
			}
	else
	{ //disable options
  }
}
void GPIO_Dinit(GPIO_Handle_t *pGPIOx)
{
	//Init Mode
	uint32_t temp=0;
	temp=GPIOHandle->GPIO_PinConfig.GPIO_PinMode<<(2*GPIOHandle->GPIOPinConfig.GPIO_PinNumber);
		GPIOHandle->pGPIOx->MODER=temp;
	//Config speed

	//config pull up or ull down

	//config o/p type

	//config alt funct
}

void PeriClkCtrl(RCC_REGDEF_t *pGPIOx,uint8_t EnorDi);
void ReadFromIpPin(GPIO_REGDEF_t *pGPIOx,uint8_t, uint8_t PinNo);
void GPIO_ReadFromIpPort(GPIO_REGDEF_t *pGPIOx);
void GPIO_WriteToOpPin(GPIO_REGDEF_t *pGPIOx,uint8_t PinNo, uint16_t value);
void GPIO_WriteToOpPort(GPIO_REGDEF_t *pGPIOx, uint16_t value);
void GPIO_ToggleOpPin(GPIO_REGDEF_t *pGPIOx, uint16_t PinNo);
